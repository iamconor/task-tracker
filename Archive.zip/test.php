<?php

echo 'hello world';
session_start();
print_r($_SESSION);